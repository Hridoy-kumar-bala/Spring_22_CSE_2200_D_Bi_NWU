package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class page2 extends AppCompatActivity {

    private Button CustomerBTN;

    private Button AdminBTN;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        CustomerBTN = findViewById(R.id.customer);

        AdminBTN = findViewById(R.id.admin);

        AdminBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goadminlogin= new Intent(page2.this, adminlogin.class);
                startActivity(goadminlogin);
            }
        });




        CustomerBTN.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent gosinguppage = new Intent(page2.this, singup.class);
                    startActivity(gosinguppage);
                }
            });


    }
}