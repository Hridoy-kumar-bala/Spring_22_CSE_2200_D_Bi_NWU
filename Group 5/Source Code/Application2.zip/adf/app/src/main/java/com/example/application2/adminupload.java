package com.example.application2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class adminupload extends AppCompatActivity {

    private Button upload_btn;
    private  Button home_btn;
    private ImageView imageView;
    private ProgressBar upload_progressBar;
    private DatabaseReference root = FirebaseDatabase.getInstance().getReference("image");
    private StorageReference reference = FirebaseStorage.getInstance().getReference();
    private Uri uriImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminupload);

        upload_btn = findViewById(R.id.bagbtn);
        imageView = findViewById(R.id.imageView);
        upload_progressBar = findViewById(R.id.upload_progressBar);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,2);
            }
        });


        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(uriImage != null )
                {
                    upload_to_firebase(uriImage);
                }
                else
                {
                    Toast.makeText(adminupload.this, "Please select an image", Toast.LENGTH_SHORT).show();
                }

            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 2 && resultCode == RESULT_OK && data != null)
        {
            uriImage = data.getData();
            imageView.setImageURI(uriImage);
        }
    }

    private  void upload_to_firebase(Uri uri)
    {
        StorageReference  fileref = reference.child(System.currentTimeMillis()+"."+ getFilExtension(uri));

        fileref.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Model model = new Model(uri.toString());
                        String modelID = root.push().getKey();
                        root.child(modelID).setValue(model);
                        upload_progressBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(adminupload.this, "Product Uploaded successfully", Toast.LENGTH_SHORT).show();
                        imageView.setImageResource(R.drawable.baseline_add_photo_alternate_24);
                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                upload_progressBar.setVisibility(View.VISIBLE);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                upload_progressBar.setVisibility(View.INVISIBLE);
                Toast.makeText(adminupload.this, "Uploading failed!!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private String getFilExtension(Uri mUri)
    {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));

    }
}