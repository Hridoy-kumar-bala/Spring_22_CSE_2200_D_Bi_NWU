package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class category extends AppCompatActivity {
    private TextView Bags;
    private TextView Watches;
    private TextView Glasses;
    private TextView Earrings;
    private TextView Necklaces;
    private TextView Rings;
    private TextView Bracelets;
    private TextView Makeup;
    private TextView Perfume;
    private TextView Hairbands;
    private TextView Shoes;

    private ImageView baseline_arrow_back_24;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        Bags = findViewById(R.id.bags);

        Glasses = findViewById(R.id.glass);
        Earrings = findViewById(R.id.earring);



        Makeup = findViewById(R.id.makeup);


        Shoes = findViewById(R.id.shoe);

        baseline_arrow_back_24 = findViewById(R.id.backpage);

        Bags.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goBagspage = new Intent(category.this, mainpage.class);
                startActivity(goBagspage);
            }
        });


        Glasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goGlassespage = new Intent(category.this, Glassimg.class);
                startActivity(goGlassespage);
            }
        });

        Earrings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goEarringspage = new Intent(category.this, Earringimg.class);
                startActivity(goEarringspage);
            }
        });






        Makeup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goMakeuppage = new Intent(category.this, makeupimg.class);
                startActivity(goMakeuppage);
            }
        });




        Shoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goShoespage = new Intent(category.this, shoe.class);
                startActivity(goShoespage);
            }
        });


        baseline_arrow_back_24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gosingup = new Intent(category.this, singup.class);
                startActivity(gosingup);
            }
        });


    }
}
