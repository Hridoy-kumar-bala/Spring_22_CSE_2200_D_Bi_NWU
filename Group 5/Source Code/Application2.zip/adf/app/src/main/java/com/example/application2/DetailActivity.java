package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

public class DetailActivity extends AppCompatActivity {

    TextView detailTitle,detailDesc,detailPrice;
    Button addToCart;
    ImageView detailImage;

    private Button orderbtn;

    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detail);
        setContentView(R.layout.activity_detail);

        orderbtn = findViewById(R.id.bag1);

        orderbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gopaymentpage = new Intent(DetailActivity.this, payment.class);
                startActivity(gopaymentpage);
            }
        });








      //  detailPrice = findViewById(R.id.detail_price);
     //  detailTitle = findViewById(R.id.detail_title);
     //   detailDesc = findViewById(R.id.detail_desc);
        detailImage = findViewById(R.id.detail_image);
     //   addToCart = findViewById(R.id.addTocart_button);

        auth = FirebaseAuth.getInstance();


        Bundle bundle = getIntent().getExtras();
        if(bundle != null)
        {
        //    detailTitle.setText(bundle.getString("Title"));
        //    detailPrice.setText(bundle.getString("Price"));
        //    detailDesc.setText(bundle.getString("Desc"));
            Glide.with(this).load(bundle.getString("Image")).into(detailImage);
        }

    }
}