package com.example.application2;

public class Model {

    private String ImageUrl;

    public Model()
    {

    }
    public  Model(String ImageUrl)
    {
        this.ImageUrl = ImageUrl;
    }

    public String getUriImage() {
        return ImageUrl;
    }

    public void setUriImage(String uriImage) {
        this.ImageUrl = uriImage;
    }
}
