package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class shipping extends AppCompatActivity {
    private Button ConfirmBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipping);
        ConfirmBTN = findViewById(R.id.orderbutton);

        ConfirmBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent golastpagepage = new Intent(shipping.this, lastpage.class);
                startActivity(golastpagepage);
            }
        });
    }
}