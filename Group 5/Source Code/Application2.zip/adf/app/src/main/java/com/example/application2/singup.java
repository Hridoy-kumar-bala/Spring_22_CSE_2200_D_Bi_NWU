package com.example.application2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class singup extends AppCompatActivity {

    private EditText userName ;
    private EditText email ;
    private EditText password ;
    private EditText repassword ;
    private Button signUpButton ;
    private FirebaseAuth firebaseAuth;
    String emailPattern = "[a-z0-9._%+-]+@[a-z0-9.-]+[a-z]{2,4}$";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);

        userName=findViewById(R.id.name);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        repassword=findViewById(R.id.repassword);
        signUpButton = findViewById(R.id.signbutton);
        firebaseAuth = FirebaseAuth.getInstance();

        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
             checkInputs()  ;

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        repassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check_email_password();
            }
        });



    }

    public void ahaa(View view) {
       Intent intent = new Intent(this, login.class);
        startActivity(intent);

    }

    private void checkInputs()
    {
        if(!TextUtils.isEmpty(userName.getText()))
        {
            if(!TextUtils.isEmpty(email.getText()))
            {
                if(!TextUtils.isEmpty(password.getText()))
                {
                    if(!TextUtils.isEmpty(repassword.getText()))
                    {
                        signUpButton.setEnabled(true);
                        signUpButton.setTextColor(getResources().getColor(R.color.black));
                    }
                    else
                    {
                        signUpButton.setEnabled(false);
                        signUpButton.setTextColor(getResources().getColor(R.color.white));
                    }
                }
                else
                {
                    signUpButton.setEnabled(false);
                    signUpButton.setTextColor(getResources().getColor(R.color.white));
                }
            }
            else
            {
                signUpButton.setEnabled(false);
                signUpButton.setTextColor(getResources().getColor(R.color.white));
            }

        }
        else
        {
            signUpButton.setEnabled(false);
            signUpButton.setTextColor(getResources().getColor(R.color.white));
        }
    }
    public void check_email_password()
    {
        if(email.getText().toString().matches(emailPattern))
        {
            if(password.getText().toString().equals(repassword.getText().toString()))
            {
                signUpButton.setEnabled(false);
                signUpButton.setTextColor(getResources().getColor(R.color.white));
                firebaseAuth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isComplete())
                                {
                                    Intent goPackPage = new Intent(singup.this, category.class);
                                    startActivity(goPackPage);
                                    finish();
                                }
                                else
                                {
                                    signUpButton.setEnabled(true);
                                    String error = task.getException().getMessage();
                                    Toast.makeText(singup.this,error,Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
            else
            {
                repassword.setError("Password doesn't match");

            }
        }
        else
        {
            email.setError("Invalid email!");
        }

    }
}

