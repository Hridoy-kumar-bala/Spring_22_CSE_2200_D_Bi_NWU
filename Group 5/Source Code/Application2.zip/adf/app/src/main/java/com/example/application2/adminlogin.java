package com.example.application2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class adminlogin extends AppCompatActivity {

    private EditText ADuserName ;
    private EditText ADemail ;
    private EditText ADpassword ;
    private EditText ADrepassword ;
    private Button LoginButton;
    private FirebaseAuth firebaseAuth;
    String emailPattern = "[a-z0-9._%+-]+@[a-z0-9.-]+[a-z]{2,4}$";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);

        ADuserName=findViewById(R.id.adminusername);
        ADemail=findViewById(R.id.adminmail);
        ADpassword=findViewById(R.id.adminpass);
        ADrepassword=findViewById(R.id.adminrepass);
        LoginButton = findViewById(R.id.adminloginbutton);
        firebaseAuth = FirebaseAuth.getInstance();

        ADuserName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs()  ;

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        ADemail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        ADpassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        ADrepassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check_email_password();
            }
        });



    }

    public void ahaa(View view) {
        Intent intent = new Intent(this, login.class);
        startActivity(intent);

    }

    private void checkInputs()
    {
        if(!TextUtils.isEmpty(ADuserName.getText()))
        {
            if(!TextUtils.isEmpty(ADemail.getText()))
            {
                if(!TextUtils.isEmpty(ADpassword.getText()))
                {
                    if(!TextUtils.isEmpty(ADrepassword.getText()))
                    {
                        LoginButton.setEnabled(true);
                        LoginButton.setTextColor(getResources().getColor(R.color.black));
                    }
                    else
                    {
                        LoginButton.setEnabled(false);
                        LoginButton.setTextColor(getResources().getColor(R.color.white));
                    }
                }
                else
                {
                    LoginButton.setEnabled(false);
                    LoginButton.setTextColor(getResources().getColor(R.color.white));
                }
            }
            else
            {
                LoginButton.setEnabled(false);
                LoginButton.setTextColor(getResources().getColor(R.color.white));
            }

        }
        else
        {
            LoginButton.setEnabled(false);
            LoginButton.setTextColor(getResources().getColor(R.color.white));
        }
    }
    public void check_email_password()
    {
        if(ADemail.getText().toString().matches(emailPattern))
        {
            if(ADpassword.getText().toString().equals(ADrepassword.getText().toString()))
            {
                LoginButton.setEnabled(false);
                LoginButton.setTextColor(getResources().getColor(R.color.white));
                firebaseAuth.createUserWithEmailAndPassword(ADemail.getText().toString(),ADpassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isComplete())
                                {
                                    Intent goPackPage = new Intent(adminlogin.this, adminselectpage.class);
                                    startActivity(goPackPage);
                                    finish();
                                }
                                else
                                {
                                    LoginButton.setEnabled(true);
                                    String error = task.getException().getMessage();
                                    Toast.makeText(adminlogin.this,error,Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
            else
            {
                ADrepassword.setError("Password doesn't match");

            }
        }
        else
        {
            ADemail.setError("Invalid email!");
        }

    }
}

