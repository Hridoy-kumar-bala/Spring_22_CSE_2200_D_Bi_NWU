package com.example.application2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {

    private Button loginbtn;
    private EditText sign_in_email;
    private EditText sign_in_password;
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+.[a-z]+";
    private FirebaseAuth firebaseAuth;
    private ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        loginbtn = findViewById(R.id.loginbutton);
        sign_in_email = findViewById(R.id.mailid);
        sign_in_password = findViewById(R.id.pass);
        firebaseAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.signIn_progressBar);

        sign_in_email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        sign_in_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkInputs();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                   check_email_password();

            }
        });


    }

    public void checkInputs() {
        if (!TextUtils.isEmpty(sign_in_email.getText())) {
            if (!TextUtils.isEmpty(sign_in_password.getText())) {
                loginbtn.setEnabled(true);
                loginbtn.setTextColor(getResources().getColor(R.color.white));
            } else {
                loginbtn.setEnabled(false);
                loginbtn.setTextColor(getResources().getColor(R.color.disiable));
            }
        } else {
            loginbtn.setEnabled(false);
            loginbtn.setTextColor(getResources().getColor(R.color.disiable));
        }


    }

    public void check_email_password() {
        if (sign_in_email.getText().toString().matches(emailPattern)) {
            if (sign_in_password.length() >= 8) {
                progressBar.setVisibility(View.VISIBLE);
                loginbtn.setEnabled(false);
                loginbtn.setTextColor(getResources().getColor(R.color.disiable));
                firebaseAuth.signInWithEmailAndPassword(sign_in_email.getText().toString(), sign_in_password.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent mainPage = new Intent(login.this, category.class);
                                    startActivity(mainPage);
                                    finish();
                                } else {
                                    progressBar.setVisibility(View.INVISIBLE);
                                    loginbtn.setEnabled(true);
                                    loginbtn.setTextColor(getResources().getColor(R.color.white));
                                    String error = task.getException().getMessage();
                                    Toast.makeText(login.this, error, Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
            } else {
                Toast.makeText(login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }

    }
}

