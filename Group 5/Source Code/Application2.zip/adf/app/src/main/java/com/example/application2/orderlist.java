package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class orderlist extends AppCompatActivity {

    private TextView Accept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderlist);
        Accept = findViewById(R.id.accept);

        Accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goconfirmlist = new Intent(orderlist.this, confirmlist.class);
                startActivity(goconfirmlist);
            }
        });
    }
}