package com.example.application2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class adminselectpage extends AppCompatActivity {

    private ImageView baseline_photo_camera_24;

    private ImageView baseline_list_24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminselectpage);

        baseline_photo_camera_24 = findViewById(R.id.uploadimg);

        baseline_list_24 = findViewById(R.id.orderimg);




        baseline_photo_camera_24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goadminupload = new Intent(adminselectpage.this, adminupload.class);
                startActivity(goadminupload);

            }
        });


        baseline_list_24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goorderlist = new Intent(adminselectpage.this, orderlist.class);
                startActivity(goorderlist);
            }
        });



    }
}